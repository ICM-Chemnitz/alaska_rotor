READONLYFILE;

TEMPLATE TSpinnerGeom(CT_Frame Frame) {
	TIvLoadGeometry Geom(Frame);
	Geom {
		GeomFile="../Geometry/spinner_ICM.wrl";
		ScaleFactor={1/1000, 1/1000, 1/1000};
	}
}
