READONLYFILE;

IMPORT "all_mbs.tpl";
IMPORT "wind.tpl";
IMPORT "../Templates/Templates.tpl";

TEMPLATE TLoadCaseRWT : TBasicLoadCase 
{
	
	InputData
	{
		FileName="../SubmodelsData/LoadCaseData.xml";
		ObjectName="Model Parameter";
	}
	
	SetInfo {
		// FileName="../LoadCases/LoadCases.xml";
		FileName="";
		SetName = "";
	}
	
	STRING CommentAdd = "--------------- Additional Turbine Configuration ------------------------";		
	// LC_OutFile = MODELNAME+"_"+ALA_PLATFORM+"_"+LC_Name;
	STRING HubLock = "OFF" ELEMENT_OF OnOff;
	STRING PitchFixed = "OFF" ELEMENT_OF OnOff;
	REAL PitchError1 = 0;
	REAL PitchError2 = 0;
	REAL PitchError3 = 0;
	REAL MassScaleFactorBlade1 = 1;
	REAL MassScaleFactorBlade2 = 1;
	REAL MassScaleFactorBlade3 = 1;
	
	
	REAL ControllerSampleRate = 0.01;	
	STRING FEBladeRigidBodySwitch = "NO" ELEMENT_OF YesNo;
	
	LC_OutFile=MODELNAME+"_"+SetInfo.SetName;
	
	TRequestRWT RequestRWT;
	RequestRWT {
		FileInfo{	
			ObjectName = "turbine";
		}
		REAL WindSpeed;
		REAL WindSlope;
		REAL WindYaw;
		WindSpeed = Wind.CurrentConditions.CurrentWindSpeed;
		WindSlope = Wind.CurrentConditions.CurrentWindSlope;
		WindYaw = Wind.CurrentConditions.CurrentWindYaw;
		REAL MeanInflow;
		MeanInflow = Wind.CurrentConditions.EstimatedMeanWindSpeed;
	}
	TPlot3 PlotWindSpeed("WindSpeed" ,Wind.CurrentConditions.CurrentWindSpeed, {201,0,0});
	TPlot4 PlotInflowAngles("det. WindSlope" ,Wind.CurrentConditions.DeterministicWindSlope, {0,201,0}, "deg");
	PlotInflowAngles {
		TOrdinate4 O2 ("det. WindSlope" ,Wind.CurrentConditions.DeterministicWindYaw, {0,0,201}, "deg");
		TOrdinate4 O3 ("turb. WindSlope" ,Wind.CurrentConditions.CurrentWindSlope, {0,101,0}, "deg");
		O3 { Pen { PenStyle=2;	} }
		TOrdinate4 O4 ("turb. WindSlope" ,Wind.CurrentConditions.CurrentWindYaw, {0,0,101}, "deg");
		O4 { Pen { PenStyle=2;	} }
	}
}

TEMPLATE TLoadCasePyRotor : TLoadCaseRWT
{
	// hub positioning
	REAL HubHeight = 140;
	REAL RotorOverhang = 5;

	REAL TiltAngle = 0;
	
	REAL BladeConeAngle = 2*RAD;
	REAL BladeRadialPosition = 2.5;
	
	STRING IsTiltAngle = "ON" ELEMENT_OF OnOff;
	
	STRING ConstrainRotorRotation = "OFF" ELEMENT_OF OnOff;
}
