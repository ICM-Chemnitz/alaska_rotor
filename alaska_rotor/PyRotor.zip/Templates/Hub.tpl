READONLYFILE;
IMPORT "all_mbs.tpl";
IMPORT "wind.tpl";
IMPORT "../Templates/Templates.tpl";

IMPORT "../Geometry/Spinner.tpl";

TEMPLATE THubRWT: THub3
{
	InputData
	{
		FileName="../SubmodelsData/HubData.xml";
		ObjectName="Model Parameter";
	}


	srcHub {
		NofBlades=3;
		RFrc_HubFlange=JointMountHub.RFrc;
		RTrq_HubFlange=JointMountHub.RTrq;
		RFrc_Hub=JointMountHub.RFrc;
		RTrq_Hub=V3pV3(V3xV3({0, 0, Parameter.DriveTrainMount_z}, JointMountHub.RFrc), JointMountHub.RTrq);
		RFrc_Nacelle=M3mV3(tgtNacelle.RelRot, RFrc_Hub);
		RTrq_Nacelle=M3mV3(tgtNacelle.RelRot, RTrq_Hub);
	}
	tgtLoadCase {
		REAL Gravity_z = -9.80665;					
	}
	tgtNacelle {
		MatchingName="srcNacelle";
		TRotMat BodyRot;
		HIDDEN TRotMat RelRot;
		RelRot=M3mM3T(M3mM3(BryantAngles2Rot(0, tgtNacelle.TiltAngle, 0), BodyRot), Hub_Body.Rot);
	}
	
	Ground {
		Gravity = {0,0,tgtLoadCase.Gravity_z};	
	}
	Hub_Body {
		IC {
			Pos=Ground.cfReferenceFrame.Pos;
			Rot=Ground.cfReferenceFrame.Rot;
			AVel={0, 0, tgtDriveTrain.OmegaIC_In};
		}
		REAL I11;
		REAL I22;
		REAL I33;
		REAL I12;
		REAL I13;
		REAL I23;
		REAL GeomLength;
		Inertia=SymMat3(I11, I22, I33, I12, I13, I23);
		CT_AbsoluteFrame Loads_HubCenter_fixHub;
		Loads_HubCenter_fixHub {
			AbsolutePos=Ground.cfReferenceFrame.Pos;
			AbsoluteRot=Ground.cfReferenceFrame.Rot;
			TIvLoadFrame IvLoadFrame;
		}
		CT_AbsoluteFrame GL_R;
		GL_R {
			AbsolutePos=Ground.cfReferenceFrame.Pos;
			AbsoluteRot=M3mM3(BryantAngles2Rot(0, PI_2, PI), Ground.cfReferenceFrame.Rot);
			TIvGLFrame IvGLFrame;
		}
		CT_AbsoluteFrame Flex_R2;
		Flex_R2 {
			AbsolutePos=Ground.cfReferenceFrame.Pos;
			AbsoluteRot=Ground.cfReferenceFrame.Rot;
			TIvFlexFrame IvFlexFrame;
		}
		TAbsoluteFrame afMainShaft;
		afMainShaft {
			AbsolutePos=Ground.cfDriveTrainMount.Pos;
			AbsoluteRot=Ground.cfDriveTrainMount.Rot;
			TIvLoadFrame Loads_HubFlange;
		}
		TFrame frSurface;
		frSurface {
			Pos={0, 0, GeomLength/2};
			Rot=BryantAngles2Rot(0, PI, 0);
		}
		TFrame Hub_Geom;
		Hub_Geom {
			Pos = {0,0,1.825};
			Rot = BryantAngles2Rot(-90*RAD,-30*RAD,0);
		}
		
		TSpinnerGeom Spinner(Hub.Hub_Body.Hub_Geom);		
		Spinner {
			Geom{
				REAL s;
				s = Parameter.BladeRadialPosition/2;	// geometry/spinner is designed for IWT turbine, which has a 2m hub radius
				ScaleFactor=RmV3(s,{1/1000, 1/1000, 1/1000});
			}
		}
		TFrame frTopBottom;
		frTopBottom {
			Rot=BryantAngles2Rot(0, PI, 0);
		}
	}
	TMountBody mtMainShaft;
	mtMainShaft {
		IC {
			Pos=Ground.cfDriveTrainMount.Pos;
			Rot=Ground.cfDriveTrainMount.Rot;
			AVel={0, 0, tgtDriveTrain.OmegaIC_In};
		}
		MatchingName="MainShaft/Hub";
		Mass=1;
		Inertia=DiagMat3(1, 1, 1);
		TAbsoluteFrame afMountHub;
		afMountHub {
			AbsolutePos=Ground.cfDriveTrainMount.Pos;
			AbsoluteRot=Ground.cfDriveTrainMount.Rot;
		}
	}
	TJointFixed JointMountHub(Hub_Body.afMainShaft, mtMainShaft.afMountHub);
	TJointRevolute RevoluteGearIn(Ground.frMainShaft, mtMainShaft.BFR);
	TRequestRWT RequestRWT;
	RequestRWT {	
		FileInfo {
			ObjectName = "turbine";
		}
		REAL RotorOmega;
		REAL RotorTrq;
		REAL TipTowerWallDistance;
		RotorOmega = srcHub.Omega;
		RotorTrq = srcHub.RTrq_Hub[3];
		TipTowerWallDistance = srcHub.Tip_TowerWall_Distance;
	}
	TPlot4 PRotorOmega("Rotor omega", srcHub.Omega, {201,0,0}, "rpm");
	TPlot3 PTTWD("tip tower wall dist", srcHub.Tip_TowerWall_Distance, {0,201,0});
}

TEMPLATE THubPyRotor : THubRWT
{
	tgtLoadCase {
		REAL HubHeight = 140;
		REAL RotorOverhang = 5;
	
		REAL TiltAngle = 0;
		
		REAL BladeConeAngle = 2*RAD;
		REAL BladeRadialPosition = 2.5;
		STRING IsTiltAngle = "ON" ELEMENT_OF OnOff;
		STRING ConstrainRotorRotation = "OFF" ELEMENT_OF OnOff;
		
		REAL TStart = 0;
		REAL OmegaIC = 0;
		REAL RotorIC = 0;
	}
	tgtNacelle {
		TiltAngle = (tgtLoadCase.IsTiltAngle == "ON") ? tgtLoadCase.TiltAngle : 0;
	}
	Parameter {
		BladeRadialPosition = tgtLoadCase.BladeRadialPosition;
		BladeConeAngle = tgtLoadCase.BladeConeAngle;
		RotorOverhang = tgtLoadCase.RotorOverhang;
	}
	Ground{
		cfReferenceFrame {
			Pos = {-Parameter.RotorOverhang, 0, tgtLoadCase.HubHeight};
		}
	}

	TBody DummyMainShaft;
	DummyMainShaft {
		TAbsoluteFrame afMainShaft;
		afMainShaft{
			AbsolutePos = Ground.cfDriveTrainMount.Pos;
			AbsoluteRot = Ground.cfDriveTrainMount.Rot;
		}
		IC {
			Pos=Ground.cfDriveTrainMount.Pos;
			Rot=Ground.cfDriveTrainMount.Rot;
			AVel={0, 0, tgtDriveTrain.OmegaIC_In};
		}
		TMountPointBody mtpMountHub;
		mtpMountHub {
			MatchingName="MainShaft/Hub";
		}
	}
	TJointRevolute JRev(Ground.frMainShaft, DummyMainShaft.afMainShaft);
	JRev {
		IC {
			Rev = tgtLoadCase.RotorIC;
			RevVel = tgtLoadCase.OmegaIC;
		}
		// set RC motion in RevoluteGearIn as given by OmegaIC_In
		// activation of RC is done via additional switch

		RC {
			Rev = tgtLoadCase.RotorIC + RevVel * (TIME-tgtLoadCase.TStart);
			RevVel = tgtLoadCase.OmegaIC;
			RevSwitch = tgtLoadCase.ConstrainRotorRotation;
		}
	
	}
	
}