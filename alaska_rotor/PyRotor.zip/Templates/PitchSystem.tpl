READONLYFILE;

IMPORT "all_mbs.tpl";
IMPORT "../Templates/Templates.tpl";
IMPORT "wind.tpl";


 /* Model comprising three individual pitch drives that are kinematically controlled */

TEMPLATE TPitchSystemRWT : TBasicPitchSystem 

{
	InputData
	{
		FileName="../SubmodelsData/PitchSystem3RC.xml";
		ObjectName="Model Parameter";
	}
	
	TPitchDriveRC PitchDrive1;
	PitchDrive1 
	{	

		tgtLoadCase {
			REAL PitchError1;
			REAL Gravity_z = -9.80665;										
		}
		PitchError = tgtLoadCase.PitchError1;
		
		tgtHub
		{
			MatchingName = "srcHub";

			TRotMat PitchDrive1Rot;
			REAL[3] PitchDrive1Pos;
			PitchDrive1Pos = {1.0,0,0};
			PitchDrive1Rot = BryantAngles2Rot(0,-PI_2,0);		
		}
					
			
		Ground
		{
			Gravity = {0,0,tgtLoadCase.Gravity_z};						
			cfReferenceFrame
			{
				Pos = tgtHub.PitchDrive1Pos;
				Rot = tgtHub.PitchDrive1Rot;			
			}			
		}
		
		mtHub
		{
			TLoadFrame Loads_PitchBearing_fixHub;
			Loads_PitchBearing_fixHub
			{
				AbsolutePos = Ground.cfPitchBearing.Pos;
				AbsoluteRot = Ground.cfPitchBearing.Rot;
			}
			
			TGLFrame GL_B;
			GL_B
			{
				AbsolutePos = Ground.cfReferenceFrame.Pos;
				AbsoluteRot = {Ground.cfReferenceFrame.Rot[1],-Ground.cfReferenceFrame.Rot[2],-Ground.cfReferenceFrame.Rot[3]};
			}
			
			TFlexFrame Flex_B;
			Flex_B
			{
				AbsolutePos = Ground.cfReferenceFrame.Pos;
				AbsoluteRot = {-Ground.cfReferenceFrame.Rot[3],Ground.cfReferenceFrame.Rot[2],Ground.cfReferenceFrame.Rot[1]};
			}			
						
		}
		TRequestRWT RequestRWT;
		RequestRWT {
			FileInfo {
				// ObjectName = "Pitch";
				HeadPrefix = "P1";
			}
			REAL PitchRev;
			REAL PitchRevVel;
			REAL PitchRevAcc;
			REAL PitchDrvTrq;
			PitchRev = JointPitchBearing.Rev;
			PitchRevVel = JointPitchBearing.RevVel;
			PitchRevAcc = JointPitchBearing.RevAcc;
			PitchDrvTrq = JointPitchBearing.RC.RTrq[3];
		}
		
	}
	
	TPitchDriveRC PitchDrive2;
	PitchDrive2
	{
	
		tgtLoadCase {
			REAL PitchError2;
			REAL Gravity_z = -9.80665;													
		}
		PitchError = tgtLoadCase.PitchError2;
		
		tgtHub
		{
			MatchingName = "srcHub";

			TRotMat PitchDrive2Rot;
			REAL[3] PitchDrive2Pos;
			PitchDrive2Pos = {1.0,0,0};
			PitchDrive2Rot = BryantAngles2Rot(0,-PI_2,0);		
		}
		
		
		Ground
		{
			Gravity = {0,0,tgtLoadCase.Gravity_z};								
			cfReferenceFrame
			{
				Pos = tgtHub.PitchDrive2Pos;
				Rot = tgtHub.PitchDrive2Rot;			
			}
		}
		
		mtHub
		{
			TLoadFrame Loads_PitchBearing_fixHub;
			Loads_PitchBearing_fixHub
			{
				AbsolutePos = Ground.cfPitchBearing.Pos;
				AbsoluteRot = Ground.cfPitchBearing.Rot;
			}
			
			TGLFrame GL_B;
			GL_B
			{
				AbsolutePos = Ground.cfReferenceFrame.Pos;
				AbsoluteRot = {Ground.cfReferenceFrame.Rot[1],-Ground.cfReferenceFrame.Rot[2],-Ground.cfReferenceFrame.Rot[3]};
			}
			
			TFlexFrame Flex_B;
			Flex_B
			{
				AbsolutePos = Ground.cfReferenceFrame.Pos;
				AbsoluteRot = {-Ground.cfReferenceFrame.Rot[3],Ground.cfReferenceFrame.Rot[2],Ground.cfReferenceFrame.Rot[1]};
			}			
		}
		TRequestRWT RequestRWT;
		RequestRWT {
			FileInfo {
				// ObjectName = "Pitch";
				HeadPrefix = "P2";
			}

			REAL PitchRev;
			REAL PitchRevVel;
			REAL PitchRevAcc;
			REAL PitchDrvTrq;
			PitchRev = JointPitchBearing.Rev;
			PitchRevVel = JointPitchBearing.RevVel;
			PitchRevAcc = JointPitchBearing.RevAcc;
			PitchDrvTrq = JointPitchBearing.RC.RTrq[3];
		}

		
	}   
	    
	TPitchDriveRC PitchDrive3;
	PitchDrive3
	{   
		
		tgtLoadCase {
			REAL PitchError3;
			REAL Gravity_z = -9.80665;													
		}
		PitchError = tgtLoadCase.PitchError3;
		
		tgtHub
		{
			MatchingName = "srcHub";
        
			TRotMat PitchDrive3Rot;
			REAL[3] PitchDrive3Pos;
			PitchDrive3Pos = {1.0,0,0};
			PitchDrive3Rot = BryantAngles2Rot(0,-PI_2,0);		
		}
		
				
		Ground
		{
			Gravity = {0,0,tgtLoadCase.Gravity_z};								
			cfReferenceFrame
			{
				Pos = tgtHub.PitchDrive3Pos;
				Rot = tgtHub.PitchDrive3Rot;			
			}
		}
		
		mtHub
		{
			TLoadFrame Loads_PitchBearing_fixHub;
			Loads_PitchBearing_fixHub
			{
				AbsolutePos = Ground.cfPitchBearing.Pos;
				AbsoluteRot = Ground.cfPitchBearing.Rot;
			}
			
			TGLFrame GL_B;
			GL_B
			{
				AbsolutePos = Ground.cfReferenceFrame.Pos;
				AbsoluteRot = {Ground.cfReferenceFrame.Rot[1],-Ground.cfReferenceFrame.Rot[2],-Ground.cfReferenceFrame.Rot[3]};
			}
			
			TFlexFrame Flex_B;
			Flex_B
			{
				AbsolutePos = Ground.cfReferenceFrame.Pos;
				AbsoluteRot = {-Ground.cfReferenceFrame.Rot[3],Ground.cfReferenceFrame.Rot[2],Ground.cfReferenceFrame.Rot[1]};
			}
						
		}
		TRequestRWT RequestRWT;
		RequestRWT {
			FileInfo {
				// ObjectName = "Pitch";
				HeadPrefix = "P3";
			}

			REAL PitchRev;
			REAL PitchRevVel;
			REAL PitchRevAcc;
			REAL PitchDrvTrq;
			PitchRev = JointPitchBearing.Rev;
			PitchRevVel = JointPitchBearing.RevVel;
			PitchRevAcc = JointPitchBearing.RevAcc;
			PitchDrvTrq = JointPitchBearing.RC.RTrq[3];

		}

	}
	TPlot4 PPitchRevs("Rev P1", PitchDrive1.JointPitchBearing.Rev,{201,0,0},"deg");
	PPitchRevs {
		TOrdinate4 O2("Rev P2", PitchDrive2.JointPitchBearing.Rev,{0,201,0},"deg");
		TOrdinate4 O3("Rev P3", PitchDrive3.JointPitchBearing.Rev,{0,0,201},"deg");
	}
	TPlot4 PPitchRevVels("RevVel P1", PitchDrive1.JointPitchBearing.RevVel,{201,0,0},"deg/s");
	PPitchRevVels {
		TOrdinate4 O2("RevVel P2", PitchDrive2.JointPitchBearing.RevVel,{0,201,0},"deg/s");
		TOrdinate4 O3("RevVel P3", PitchDrive3.JointPitchBearing.RevVel,{0,0,201},"deg/s");
	}
	TPlot4 PPitchRevAccs("RevAcc P1", PitchDrive1.JointPitchBearing.RevVel,{201,0,0},"deg/s/s");
	PPitchRevAccs {
		TOrdinate4 O2("RevAcc P2", PitchDrive2.JointPitchBearing.RevVel,{0,201,0},"deg/s/s");
		TOrdinate4 O3("RevAcc P3", PitchDrive3.JointPitchBearing.RevVel,{0,0,201},"deg/s/s");
	}
	TPlot3 PPitchDrvTrqs("RevTrq P1", PitchDrive1.JointPitchBearing.RC.RTrq[3],{201,0,0});
	PPitchDrvTrqs {
		TOrdinate3 O2("RevTrq P2", PitchDrive2.JointPitchBearing.RC.RTrq[3],{0,201,0});
		TOrdinate3 O3("RevTrq P3", PitchDrive3.JointPitchBearing.RC.RTrq[3],{0,0,201});
	}

}
