READONLYFILE;

TEMPLATE TWT_MCMIntegration: TBatch
{
	TTaskAssembly Assembly;
	Assembly {
		DefaultState {
			ModellingMode="Absolute";
		}
		InState.Time=LoadCase.TStart;
		LogFileName=LoadCase.OutputDir+LoadCase.LC_OutFile+".log";
		OutputFileName=LoadCase.OutputDir+LoadCase.LC_OutFile+".out";
		StateFileName=LoadCase.OutputDir+LoadCase.LC_OutFile+".stf";
		DeleteStateFile="ON";
	}
	TTaskIntegration Integration;
	Integration {
		EndTime=LoadCase.TEnd;
		StepTime=LoadCase.TStep;
		InState.Time=LoadCase.TStart;
		WriteOutputs="ON";
		StateFileName=LoadCase.OutputDir+LoadCase.LC_OutFile+".stf";
		LogFileName=LoadCase.OutputDir+LoadCase.LC_OutFile+".log";
		OutputFileName=LoadCase.OutputDir+LoadCase.LC_OutFile+".out";
		WriteStates="OFF";
		Integrator="Shampine";
	}
}

TEMPLATE TWT_MCMLinear: TBatch
{
	TTaskAssembly Assembly;
	Assembly {
		DefaultState {
			ModellingMode="Absolute";
		}
		InState.Time=LoadCase.TStart;
		LogFileName=LoadCase.OutputDir+LoadCase.LC_OutFile+".log";
		OutputFileName=LoadCase.OutputDir+LoadCase.LC_OutFile+".out";
		StateFileName=LoadCase.OutputDir+LoadCase.LC_OutFile+".stf";
		DeleteStateFile="ON";
	}
	TTaskLinear TaskLinear;
	TaskLinear {
		InState {
			Name="Assembly";
			Time=LoadCase.TStart;
		}
		StateFileName=LoadCase.OutputDir+LoadCase.LC_OutFile+".stf";
		OutputFileName=LoadCase.OutputDir+LoadCase.LC_OutFile+".out";		
		Scale=200;
		LogFileName=LoadCase.OutputDir+LoadCase.LC_OutFile+".log";
		SortEpsilon=0.01;
	}
	TTaskLinearResults LinearResults;
	LinearResults {
		InState {
			Name="Linear";
		}
		StateFileName=LoadCase.OutputDir+LoadCase.LC_OutFile+".stf";
		LogFileName=LoadCase.OutputDir+LoadCase.LC_OutFile+".log";
		Scale=150;
	}
}

TEMPLATE TWT_ACMIntegration: TBatch
{
	TTaskAssembly Assembly;
	Assembly {
		DefaultState {
			ModellingMode="Absolute";
		}
		InState.Time=LoadCase.TStart;
		LogFileName=LoadCase.OutputDir+LoadCase.LC_OutFile+".log";
		OutputFileName=LoadCase.OutputDir+LoadCase.LC_OutFile+".out";
		StateFileName=LoadCase.OutputDir+LoadCase.LC_OutFile+".stf";
		DeleteStateFile="ON";
	}
	TStateToCompliant StateToCompliant;
	StateToCompliant {
		InState {
			Time=LoadCase.TStart;
		}
		StateFileName=LoadCase.OutputDir+LoadCase.LC_OutFile+".stf";
		OutputFileName=LoadCase.OutputDir+LoadCase.LC_OutFile+".out";
		LogFileName=LoadCase.OutputDir+LoadCase.LC_OutFile+".log";
	}
	TCompliantIntegration CompliantIntegration;
	CompliantIntegration {
		InState {
			Time=LoadCase.TStart;
		}
		StateFileName=LoadCase.OutputDir+LoadCase.LC_OutFile+".stf";
		OutputFileName=LoadCase.OutputDir+LoadCase.LC_OutFile+".out";
		LogFileName=LoadCase.OutputDir+LoadCase.LC_OutFile+".log";
		WriteStates="OFF";
		StepTimeControl="FirstSteps";
		StepTime=LoadCase.TStep;
		EndTime=LoadCase.TEnd;
		WriteOutputs="ON";
	}
}

TEMPLATE TWT_ACMLinear: TBatch
{
	TTaskAssembly Assembly;
	Assembly {
		DefaultState {
			ModellingMode="Absolute";
		}
		InState.Time=LoadCase.TStart;
		LogFileName=LoadCase.OutputDir+LoadCase.LC_OutFile+".log";
		OutputFileName=LoadCase.OutputDir+LoadCase.LC_OutFile+".out";
		StateFileName=LoadCase.OutputDir+LoadCase.LC_OutFile+".stf";
		DeleteStateFile="ON";
	}
	TStateToCompliant StateToCompliant;
	StateToCompliant {
		InState {
			Time=LoadCase.TStart;
		}
		StateFileName=LoadCase.OutputDir+LoadCase.LC_OutFile+".stf";
		OutputFileName=LoadCase.OutputDir+LoadCase.LC_OutFile+".out";
		LogFileName=LoadCase.OutputDir+LoadCase.LC_OutFile+".log";
	}
	TCompliantLinear CompliantLinear;
	CompliantLinear {
		InState {
			Name="Assembly";
			Time=LoadCase.TStart;
		}
		StateFileName=LoadCase.OutputDir+LoadCase.LC_OutFile+".stf";
		LogFileName=LoadCase.OutputDir+LoadCase.LC_OutFile+".log";
		OutputFileName=LoadCase.OutputDir+LoadCase.LC_OutFile+".out";
	}
	TTaskLinearResults LinearResults;
	LinearResults {
		InState {
			Name="Linear";
		}
		StateFileName=LoadCase.OutputDir+LoadCase.LC_OutFile+".stf";
		LogFileName=LoadCase.OutputDir+LoadCase.LC_OutFile+".log";
	}
}
