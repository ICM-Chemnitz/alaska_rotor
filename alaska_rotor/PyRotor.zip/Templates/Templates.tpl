READONLYFILE;
READFILEONCE;



// ----- reference turbine versioning -----------------------------

TEMPLATE TRWTVersion : TContainer
{
	STRING alaska_RWTVersionNumber;
	STRING RWTReference;
	STRING RWTRefLink;
}


// ----- definition of requests -----------------------------



TEMPLATE TRequestRWT : TRequest
{
	TTarget tgtLoadCase;
	tgtLoadCase{
		MatchingName = "srcLoadCase";
		STRING OutputDir;
		STRING RequestFileName;
		REAL TOutput;
	}
	FileInfo {


		Prefix = "hdf5"; // set Prefix to hdf5 to change file format
		// Prefix = "xml";
		// file name of exported data file
		FileName = tgtLoadCase.OutputDir+tgtLoadCase.RequestFileName+"."+Prefix;
		ObjectName = "turbine";
		StartTime = tgtLoadCase.TOutput;
	}
	
}

TEMPLATE TBladeRequestRWT : TRequestRWT
{
	FileInfo{
		// ObjectName = "Blade"+ I2S(BladeNumber);
	}
}

TEMPLATE TRequestRWTBladeLoads(REAL[3] InternalFrc,  REAL[3] InternalTrq, INT Index) : TBladeRequestRWT
{
	FileInfo{
		HeadPrefix = "B"+I2S(BladeNumber)+"L"+ I2S(Index);	// loads, i. e. 3-dimensional internal force and torque
	}
	REAL[3] RFrc;
	REAL[3] RTrq;
	RFrc = InternalFrc;
	RTrq = InternalTrq;
}

TEMPLATE TRequestRWTTowerLoads(REAL[3] InternalFrc,  REAL[3] InternalTrq, INT Index) : TRequestRWT
{
	FileInfo{
		HeadPrefix = "T"+"L"+ I2S(Index);	// loads, i. e. 3-dimensional internal force and torque
	}
	REAL[3] RFrc;
	REAL[3] RTrq;
	RFrc = InternalFrc;
	RTrq = InternalTrq;
}


TEMPLATE TRequestRWTBladeForce(REAL FLift, REAL FDdrag, REAL Moment, INT Index) : TBladeRequestRWT
{
	FileInfo{
		HeadPrefix = "B"+I2S(BladeNumber)+"AF"+ I2S(Index);	// aerodynamic force
	}
	REAL FL;
	REAL FD;
	REAL T;
	FL  = FLift;
	FD  = FDdrag;
	T   = Moment;
}

TEMPLATE TRequestRWTBladeForceWake(REAL AttackAngle, REAL AxInduction, INT Index) : TBladeRequestRWT
{
	FileInfo{
		HeadPrefix = "B"+I2S(BladeNumber)+"AF"+ I2S(Index);	// aerodynamic properties 
	}
	REAL AoA;
	REAL a;
	AoA = AttackAngle;
	a   = AxInduction;
}

TEMPLATE TRequestRWTBladeNodePos(CT_Frame Node, INT Index) : TRequestRWT
{
	FileInfo{
		HeadPrefix = "B"+I2S(BladeNumber)+"N"+ I2S(Index);	// node position of flexible body
	}
	REAL[3] Pos;
	Pos = Node.Pos;
}

TEMPLATE TRequestBladeNodeDefl(REAL[3] Pos, REAL[3][3] Rot, INT Index) : TRequestRWT 
{
	FileInfo{
		HeadPrefix = "B"+I2S(BladeNumber)+"D"+ I2S(Index);	
	}

	REAL PosY;
	REAL PosZ;
	REAL RotX;
	STRING[3] Units={"m", "m", "deg"};
	PosY=Pos[2];
	PosZ=Pos[3];
	RotX=V3TmV3(Rot2BryantAngles(Rot),{1,0,0});
}

TEMPLATE TBladeTipDeformations : TContainer
{
	TTarget tgtBlade1;
	tgtBlade1 {
		REAL DeflectionEdge;
		REAL DeflectionFlap;
		MatchingName="srcBlade1";
	}
	TTarget tgtBlade2;
	tgtBlade2 {
		REAL DeflectionEdge;
		REAL DeflectionFlap;
		MatchingName="srcBlade2";
	}
	TTarget tgtBlade3;
	tgtBlade3 {
		REAL DeflectionEdge;
		REAL DeflectionFlap;
		MatchingName="srcBlade3";
	}
	TPlot3 PlotDeflectionFlap("DeflFlap B1", tgtBlade1.DeflectionFlap, {201, 0, 0});
	PlotDeflectionFlap {
		TOrdinate3 O2("DeflFlap B2", tgtBlade2.DeflectionFlap, {0, 201, 0});
		TOrdinate3 O3("DeflFlap B3", tgtBlade3.DeflectionFlap, {0, 0, 201});
	}
	TPlot3 PlotDeflectionEdge("DeflEdge B1", tgtBlade1.DeflectionEdge, {201, 0, 0});
	PlotDeflectionEdge {
		TOrdinate3 O2("DeflEdge B2", tgtBlade2.DeflectionEdge, {0, 201, 0});
		TOrdinate3 O3("DeflEdge B3", tgtBlade3.DeflectionEdge, {0, 0, 201});
	}
}
